# Fyntwin — Financial Health Monitor

> Intelligent personal-finance assistant that analyses your spending across three dimensions — budget adherence, month-over-month trends, and spending concentration — and returns a structured **(Red / Amber / Green)** health report.

---

## 🎬 Demo Video

**[Watch the end-to-end demo (YouTube Unlisted / Loom)](YOUR_VIDEO_LINK_HERE)**

> Shows: Green month (Feb 2026) → short summary path; Red month (Apr 2026) → full remediation path.

---

## What the System Does

A user types a natural-language question like:

> *"Give me a financial health report for April 2026 — budget, trend, and where my money went."*

The system:
1. **Fetches** transactions, budgets, and category data from Postgres for the requested month.
2. **Runs three specialist AI agents in parallel** — each analyses one financial dimension.
3. **Derives an overall health status** (Green / Amber / Red) from the three sub-statuses.
4. **Branches conditionally**: if RED, runs an extra remediation step for concrete suggestions.
5. **Returns a structured `HealthReport`** with per-dimension findings, an executive summary, and (when RED) remediation suggestions.

### Financial Dimensions Analysed

| Dimension | What it measures | Red trigger |
|---|---|---|
| **Budget Health** | Spend vs monthly limit per category | ≥ 2 categories overspent |
| **Spending Trend** | Month-over-month total spend change | Spend rose ≥ 10% vs prior month |
| **Concentration Risk** | Share of spend in one category + large single charge | Top category > 40% **or** a single charge > ₹10,000 |

---

## Architecture

```
User prompt
    │
    ▼
FastAPI  POST /api/v1/run
    │
    ▼
run_financial_workflow()   ← agents/team.py
    │
    ├──── [PARALLEL via ThreadPoolExecutor] ────────────────────────┐
    │         Budget Agent  → spend_by_category + get_budgets        │
    │         Trend Agent   → get_monthly_totals (2 months)          │
    │         Concentration → spend_by_category + get_largest_txn    │
    │                                                                │
    │◄──────────────────────────────────────────────────────────────┘
    │
    ├── Derive overall status
    │
    ├── IF RED → Remediation step (Anthropic API, sync)
    │   ELSE   → Skip (Green / Amber fast path)
    │
    └── Assemble HealthReport → JSON → Frontend
```

---

## Why Parallel Team Mode?

Budget analysis, trend analysis, and concentration analysis each look at **different attributes** of the same source data and produce **completely independent outputs** — none of them needs to read another agent's result to do its job.

Running them **concurrently** (via Python's `ThreadPoolExecutor`, mirroring Agno's `coordinate`/parallel team mode) means all three analyses complete in the time it takes the slowest one, rather than summing all three latencies sequentially. For a user waiting on a live API call, this is a meaningful UX improvement.

A single team coordinator then synthesises the three independent JSON reports into one cohesive `HealthReport`.

---

## Workflow Conditional Branch

```
                  ┌──────────────────────┐
                  │  Derive overall       │
                  │  status from 3 agents │
                  └──────────┬───────────┘
                             │
              ┌──────────────┼──────────────┐
              │                             │
        overall == RED              overall == Green/Amber
              │                             │
              ▼                             ▼
   Run Remediation Step           Skip Remediation
   (concrete suggestions          (short executive
    to cut spending)               summary only)
              │                             │
              └──────────────┬──────────────┘
                             │
                    Assemble HealthReport
```

**Trigger:** `_derive_overall()` in `agents/team.py` counts how many of the three sub-statuses are non-Green. Two or more → RED → remediation branch runs. Fewer than two → Green or Amber → fast path, no extra LLM call.

---

## Project Structure

```
fyntwin/
├── backend/
│   ├── main.py                    # FastAPI app entry point
│   ├── config.py                  # pydantic-settings, loads .env
│   ├── routes/
│   │   ├── agent.py               # POST /api/v1/run
│   │   └── health.py              # GET /api/v1/health | GET /api/v1/history
│   ├── agents/
│   │   ├── team.py                # Agno Team orchestration + Workflow
│   │   ├── budget_agent.py        # Specialist agent 1: budget vs spend
│   │   ├── trend_agent.py         # Specialist agent 2: MoM trend
│   │   └── concentration_agent.py # Specialist agent 3: spend concentration
│   ├── tools/
│   │   └── finance_tools.py       # 5 Agno tool functions (DB-backed)
│   ├── schemas/
│   │   └── models.py              # All Pydantic request/response models
│   └── services/
│       └── db.py                  # Reusable Postgres access layer
├── data/
│   ├── seed.sql                   # Schema + seeded transactions (auto-generated)
│   ├── transactions.csv           # Raw CSV (auto-generated)
│   └── generate_data.py           # Synthetic data generator (stdlib only)
├── frontend/
│   └── index.html                 # Single-file React-free UI
├── .env.example
├── requirements.txt               # Pinned: agno==1.4.2
└── README.md
```

---

## Setup & Run (under 5 minutes)

### Prerequisites
- Python 3.11+
- Docker (for Postgres)
- An Anthropic API key

### 1. Clone & install dependencies

```bash
git clone https://github.com/YOUR_USERNAME/fyntwin
cd fyntwin
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Start Postgres with Docker

```bash
docker run -d \
  --name fyntwin-pg \
  -e POSTGRES_USER=fyntwin \
  -e POSTGRES_PASSWORD=fyntwin_pass \
  -e POSTGRES_DB=fyntwin \
  -p 5432:5432 \
  postgres:16
```

### 3. Configure environment

```bash
cp .env.example .env
# Edit .env — set your ANTHROPIC_API_KEY
# DATABASE_URL is already correct for the Docker setup above
```

### 4. Generate synthetic data and seed the DB

```bash
python data/generate_data.py          # creates seed.sql + transactions.csv
psql postgresql://fyntwin:fyntwin_pass@localhost:5432/fyntwin -f data/seed.sql
```

Expected output:
```
2026-02  disc_spend= 15300  trend=ok      -> GREEN
2026-04  disc_spend= 43100  trend=RISING  -> RED    over=[Food,Transport,Entertainment,Shopping]; concentration(Shopping 42%)
```

### 5. Start the backend

```bash
cd fyntwin
uvicorn backend.main:app --reload --port 8000
```

Visit **http://localhost:8000/docs** to see the OpenAPI UI.

### 6. Open the frontend

```bash
open frontend/index.html   # or just open the file in your browser
```

---

## API Endpoints

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/v1/health` | Service name, version, status |
| `POST` | `/api/v1/run` | Run agent team, return structured health report |
| `GET` | `/api/v1/history` | Past session runs from Agno's Postgres storage |

### Example request

```bash
curl -X POST http://localhost:8000/api/v1/run \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"Financial health for April","year":2026,"month":4}'
```

---

## Demo Scenarios

| Month | Expected Status | Why |
|---|---|---|
| Feb 2026 | 🟢 **Green** | Under budget in all categories, spend fell vs Jan |
| Apr 2026 | 🔴 **Red** | Over budget in Food/Entertainment/Shopping, spend spiked 123%, Shopping at 42% concentration |

---

## Design Decisions

- **No ORM** — SQLAlchemy Core only; queries stay readable, no magic.
- **Single DB access layer** — `services/db.py` is the only place SQL lives.
- **Agents never compute** — all arithmetic is in Python tools / the db layer; the model only *explains* numbers.
- **Pinned Agno version** — `agno==1.4.2` to avoid breaking API changes.
- **Parallel agents** — `ThreadPoolExecutor(max_workers=3)` mirrors Agno Team's coordinate mode for real concurrency.

---

## Notes

- Do **not** commit `.env`. Only `.env.example` is in the repo.
- This is a budgeting tool. It never suggests investments or loans.
- All data is synthetic. No real financial information is used anywhere.
